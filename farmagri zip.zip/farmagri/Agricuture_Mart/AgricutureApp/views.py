from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect

# Create your views here.
from django.views.generic import TemplateView

from AgricutureApp.models import Customer_Reg, UserType, Farmer_Reg


class IndexView(TemplateView):
    template_name = 'index.html'


class Customer_reg(TemplateView):
    template_name = 'customer_reg.html'

    def post(self, request, *args, **kwargs):
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        con_password = request.POST['con_password']

        address = request.POST['address']
        if password == con_password:

            if User.objects.filter(email=email):
                print('pass')
                return render(request, 'customer_reg.html', {'message': "already added the email"})

            else:
                user = User.objects._create_user(username=email, password=password, email=email, first_name=name,
                                                 is_staff='0', last_name='0')
                user.save()
                customer = Customer_Reg()
                customer.user = user
                customer.address \
                    = address
                customer.con_password=con_password
                customer.save()
                usertype = UserType()

                usertype.user = user
                usertype.type = "customer"
                usertype.save()
                return render(request, 'customer_reg.html', {'message': "successfully added"})
        else:
            return render(request, 'customer_reg.html', {'message': "password didn't match"})


class Farmer_Registration(TemplateView):
    template_name = 'farmer_reg.html'

    def post(self, request, *args, **kwargs):
        farmername = request.POST['farmername']
        address = request.POST['address']
        phonenumber = request.POST['phonenumber']
        email = request.POST['email']
        # image = request.FILES['image']
        # fi = FileSystemStorage()
        # files = fi.save(image.name, image)
        password = request.POST['password']
        con_password = request.POST['con_password']

        if password == con_password:

            if User.objects.filter(email=email):
                print('pass')
                return render(request, 'farmer_reg.html', {'message': "already added the username or email"})

            else:
                user = User.objects._create_user(username=email, password=password, email=email, first_name=farmername,
                                                 is_staff='0', last_name='0')
                user.save()
                farmer = Farmer_Reg()
                farmer.user = user
                farmer.phonenumber = phonenumber
                farmer.address = address
                farmer.con_password = con_password
                # shop.image = files

                farmer.save()
                usertype = UserType()
                usertype.user = user
                usertype.type = "farmer"
                usertype.save()

                return render(request, 'farmer_reg.html', {'message': "successfully added"})
        else:
            return render(request, 'farmer_reg.html', {'message': "password didn't match"})

class Login(TemplateView):
    template_name = 'login.html'

    def post(self, request, *args, **kwargs):
        email = request.POST['email']
        password = request.POST['password']

        user = authenticate(username=email, password=password)

        if user is not None:
            login(request, user)
            if user.last_name == '1':
                if user.is_superuser:
                    return redirect('/admin')
                elif UserType.objects.get(user_id=user.id).type == "customer":
                    return redirect('/customer')
                elif UserType.objects.get(user_id=user.id).type == "farmer":
                    return redirect('/farmer')
            # elif UserType.objects.get(user_id=user.id).type == "pharmacy":
            #     return redirect('/pharmacy')

            else:
                return render(request, 'login.html', {'message': " User Account Not Authenticated"})


        else:
            return render(request, 'login.html', {'message': "Invalid Username or Password"})