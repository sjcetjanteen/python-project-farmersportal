from django.urls import path


from AgricutureApp.customer_views import IndexView, Viewproducts, Singleproducts, CartView, ViewCart, RejectcartView, \
    Checkout, payment, Buynow, Direct_checkout, Direct_payment, BookingView, View_Category, Add_complaint, \
    Complaint_replay, My_Profile, feedback

urlpatterns = [

    path('',IndexView.as_view()),
    path('viewproduct',Viewproducts.as_view()),
    path('single_view',Singleproducts.as_view()),
    path('cart',CartView.as_view()),
    path('view_cart',ViewCart.as_view()),
    path('removecart',RejectcartView.as_view()),
    path('checkout',Checkout.as_view()),
    path('payment',payment.as_view()),
    path('buy_now',Buynow.as_view()),
    path('d_checkout',Direct_checkout.as_view()),
    path('d_payment',Direct_payment.as_view()),
    path('my_booking',BookingView.as_view()),
    path('view_categ', View_Category.as_view()),
    path('add_compl',Add_complaint.as_view()),
    path('view_replay',Complaint_replay.as_view()),
    path('my_profile',My_Profile.as_view()),
    path('feedback',feedback.as_view())

]
def urls():
    return urlpatterns, 'customer', 'customer'