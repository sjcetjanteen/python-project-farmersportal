from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.shortcuts import redirect, render
from django.views.generic import TemplateView

from AgricutureApp.models import Categ, Product, Farmer_Reg, Cart, Feedback


class IndexView(TemplateView):
    template_name = 'farmer/farmer_index.html'

# class Category(TemplateView):
#     template_name = 'farmer/category.html'
#
#     def post(self, request, *args, **kwargs):
#         name = request.POST['name']
#         categ = Categ()
#         categ.name = name
#         categ.save()
#         return redirect(request.META['HTTP_REFERER'])

class AddProduct(TemplateView):
    template_name = 'farmer/Add_product.html'

    def get_context_data(self, **kwargs):
        context = super(AddProduct, self).get_context_data(**kwargs)
        category = Categ.objects.all()
        context['category'] = category
        return context

    def post(self, request, *args, **kwargs):
        user = User.objects.get(pk=self.request.user.id)

        name = request.POST['name']
        farmer = Farmer_Reg.objects.get(user_id=self.request.user.id)

        category = request.POST['category']
        price = request.POST['price']
        desc = request.POST['desc']
        stock=request.POST['stock']
        exdate=request.POST['exdate']
        image = request.FILES['image']
        fii = FileSystemStorage()
        filesss = fii.save(image.name, image)

        se = Product()

        se.user_id = farmer.id
        se.name = name
        se.exdate=exdate
        se.farmer = user
        se.image = filesss
        se.catg_id = category

        se.price = price
        se.desc = desc
        se.stock=stock

        se.save()

        return redirect(request.META['HTTP_REFERER'], {'message': "product successfully added "})

class Farmer_productview(TemplateView):
    template_name ='farmer/View_product.html'

    def get_context_data(self, **kwargs):

        context = super(Farmer_productview,self).get_context_data(**kwargs)

        view_pr = Product.objects.filter(farmer_id=self.request.user.id)

        context['view_pr'] = view_pr
        return context

class Delete_product(TemplateView):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        Product.objects.get(id=id).delete()

        return render(request,'farmer/View_product.html',{'message':"Photo Removed"})

class Feedback_view(TemplateView):
    template_name ='farmer/view_feedback.html'

    def get_context_data(self, **kwargs):

        context = super(Feedback_view,self).get_context_data(**kwargs)

        view_fe = Farmer_Reg.objects.get(user_id=self.request.user.id)
        feed=Feedback.objects.filter(farmer_id=view_fe.id)
        context['feed'] = feed
        return context

class View_booking(TemplateView):
    template_name ='farmer/booking.html'

    def get_context_data(self, **kwargs):

        context = super(View_booking,self).get_context_data(**kwargs)

        view_book = Farmer_Reg.objects.get(user_id=self.request.user.id)
        farmer=Cart.objects.filter(farmer_id=view_book.id,status='paid',delivery='delivered')
        context['farmer'] = farmer
        return context