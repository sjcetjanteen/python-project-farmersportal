from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.views.generic.base import View

from AgricutureApp.models import Farmer_Reg, Customer_Reg, Compalaint, Categ, Cart


class IndexView(TemplateView):
    template_name = 'admin/admin_index.html'


class Farmer_Approvel(TemplateView):
    template_name = 'admin/farmer_approve.html'

    def get_context_data(self, **kwargs):
        context = super(Farmer_Approvel,self).get_context_data(**kwargs)

        farmer = Farmer_Reg.objects.filter(user__last_name='0',user__is_staff='0',user__is_active='1')

        context['farmer'] = farmer
        return context

class Customer_approvel(TemplateView):
    template_name = 'admin/customer_approve.html'

    def get_context_data(self, **kwargs):
        context = super(Customer_approvel,self).get_context_data(**kwargs)

        custr = Customer_Reg.objects.filter(user__last_name='0',user__is_staff='0',user__is_active='1')

        context['custr'] = custr
        return context

class ApproveView(View):
    def dispatch(self, request, *args, **kwargs):

        id = request.GET['id']
        user = User.objects.get(pk=id)
        user.last_name='1'
        user.save()
        return render(request,'admin/admin_index.html',{'message':" Account Approved"})

class RejectView(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        user = User.objects.get(pk=id)
        user.last_name='1'
        user.is_active='0'
        user.save()
        return render(request,'admin/admin_index.html',{'message':"Account Removed"})

class Complaint_View(TemplateView):
    template_name = 'admin/view_complaint.html'

    def get_context_data(self, **kwargs):
        context = super(Complaint_View,self).get_context_data(**kwargs)

        compl = Compalaint.objects.filter(status='added')

        context['compl'] = compl
        return context

    def post(self, request, *args, **kwargs):
        # complaint = actions.objects.get(user_id=self.request.id)
        id = request.POST['id']
        action = request.POST['action']
        act = Compalaint.objects.get(id=id)
        # act.complaint=complaint
        act.action = action

        act.status = 'replied'
        act.save()

        return redirect(request.META['HTTP_REFERER'])


class Category(TemplateView):
    template_name = 'admin/category.html'

    def post(self, request, *args, **kwargs):
        name = request.POST['name']
        categ = Categ()
        categ.name = name
        categ.save()
        return redirect(request.META['HTTP_REFERER'])



class BookingView(TemplateView):
    template_name = 'admin/booking.html'
    def get_context_data(self, **kwargs):
        context = super(BookingView,self).get_context_data(**kwargs)
        view_b = Cart.objects.filter(status='paid',delivery='delivered')

        context['view_b'] = view_b
        return context

class Customer_View(TemplateView):
    template_name = 'admin/customer_list.html'
    def get_context_data(self, **kwargs):
        context = super(Customer_View,self).get_context_data(**kwargs)

        view_cust = Customer_Reg.objects.filter(user__last_name='1',user__is_staff='0',user__is_active='1')

        context['view_cust'] = view_cust
        return context

class farmer_View(TemplateView):
    template_name = 'admin/farmer_list.html'
    def get_context_data(self, **kwargs):
        context = super(farmer_View,self).get_context_data(**kwargs)

        view_shop = Farmer_Reg.objects.filter(user__last_name='1',user__is_staff='0',user__is_active='1')

        context['view_shop'] = view_shop
        return context

class Delete_Farmer(TemplateView):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        id1 = request.GET['userid']

        Farmer_Reg.objects.get(id=id).delete()
        User.objects.get(id=id1).delete()

        return redirect(request.META['HTTP_REFERER'])
