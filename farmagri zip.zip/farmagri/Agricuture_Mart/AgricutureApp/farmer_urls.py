from django.urls import path
from AgricutureApp.farmer_views import IndexView,AddProduct, View_booking, Farmer_productview, \
    Delete_product, Feedback_view

urlpatterns = [

    path('',IndexView.as_view()),
    # path('category',Category.as_view()),
    path('addProduct',AddProduct.as_view()),
    path('booking',View_booking.as_view()),
    path('productview',Farmer_productview.as_view()),
    path('delete',Delete_product.as_view()),
    path('view_feedback',Feedback_view.as_view())
    ]
def urls():
    return urlpatterns, 'farmer','farmer'