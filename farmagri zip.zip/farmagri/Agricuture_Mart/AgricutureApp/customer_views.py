from django.contrib.auth.models import User
from datetime import date
from django.shortcuts import redirect, render
from django.views.generic import TemplateView

from AgricutureApp.models import Farmer_Reg, Categ, Product, Cart, Checkout_details, Feedback, Compalaint, Customer_Reg


class IndexView(TemplateView):
    template_name = 'customer/productview.html'

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        view_pp = Product.objects.all()
        today = date.today().isoformat()
        for i in view_pp:
            if i.exdate <= today:
                Product.objects.get(id=i.id).delete()
            continue

        category = Categ.objects.all()
        context['category'] = category
        context['view_pp'] = view_pp
        return context

class Viewproducts(TemplateView):
    template_name = 'customer/productview.html'
    def get_context_data(self, **kwargs):
        id =self.request.GET['id']

        context = super(Viewproducts, self).get_context_data(**kwargs)
        category = Categ.objects.all()
        context['category'] = category
        today = date.today().isoformat()
        print("fdf",today)
        farmer = Farmer_Reg.objects.get(user_id=id)

        view_prodt = Product.objects.filter(user_id=farmer.id)
        context['today'] = today
        for i in view_prodt:
            if i.exdate >= today:
                Product.objects.get(id=i.id).delete()
            continue

        context['view_prodt'] = view_prodt
        context['userid']=id
        return context

class View_Category(TemplateView):
    template_name = 'customer/category_view.html'
    def get_context_data(self, **kwargs):
        cat_id = self.request.GET['catg_id']
        context = super(View_Category,self).get_context_data(**kwargs)
        category = Categ.objects.all()
        view_ct = Product.objects.filter(catg_id=cat_id)
        context['category'] = category
        context['view_pp'] = view_ct
        return context


class Singleproducts(TemplateView):
    template_name = 'customer/singleview.html'

    def get_context_data(self, **kwargs):
        id =self.request.GET['id']

        context = super(Singleproducts, self).get_context_data(**kwargs)

        single_view = Product.objects.get(id=id)

        context['single_view'] = single_view
        return context

    def post(self, request, *args, **kwargs):
        user = User.objects.get(id=self.request.user.id)

        id2 = request.POST['product_id']
        farmer=Product.objects.get(id=id2)
        print(id2, 'hggvjkjkj')
        name = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']
        fe = Feedback()
        fe.farmer_id=farmer.user_id
        fe.user = user
        fe.product_id = id2

        fe.name = name
        fe.email = email
        fe.subject = subject
        fe.message = message
        fe.save()
        return render(request,'customer/singleview.html',{'message':"Feedback Added"})

class CartView(TemplateView):
    template_name = 'customer/singleproduct_view.html'

    def dispatch(self, request, *args, **kwargs):
        pid = request.POST['id']
        qunty = request.POST['quantity']
        farmer = Product.objects.get(pk=pid)
        price = farmer.price
        Total = int(qunty) * int(price)
        farmer.stock = int(farmer.stock) - int(qunty)
        a = int(farmer.stock) - int(qunty)
        if a <= 0:
            return redirect(request.META['HTTP_REFERER'])
        else:

            farmer.save()
            farmer_reg = Farmer_Reg.objects.get(id=farmer.user_id)
            ca = Cart()
            ca.user = User.objects.get(id=self.request.user.id)
            ca.farmer_id = farmer_reg.id
            ca.product = Product.objects.get(pk=pid)
            ca.payment = 'null'
            ca.quantity = qunty
            ca.status = 'cart'
            ca.delivery = 'null'
            ca.total = Total
            ca.save()
            return redirect(request.META['HTTP_REFERER'])

class ViewCart(TemplateView):
    template_name = 'customer/cart.html'

    def get_context_data(self, **kwargs):
        context = super(ViewCart, self).get_context_data(**kwargs)
        # user = User.objects.get(id=self.request.user.id)
        # id =self.request.GET['id']

        cr = self.request.user.id

        ct = Cart.objects.filter(status='cart', user_id=cr, delivery='null')

        total = 0
        for i in ct:
            total = total + int(i.total)

        context['ct'] = ct
        context['asz'] = total

        return context

class RejectcartView(TemplateView):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        Cart.objects.get(id=id).delete()

        return redirect(request.META['HTTP_REFERER'])

class Checkout(TemplateView):
    template_name = 'customer/checkout.html'

    def get_context_data(self, **kwargs):
        context = super(Checkout, self).get_context_data(**kwargs)
        # user = User.objects.get(id=self.request.user.id)

        cr = self.request.user.id
        ctr = Cart.objects.filter(status='cart', user_id=cr, delivery='null')

        total = 0
        for i in ctr:
            total = total + int(i.total)
        print(total)

        context['ctr'] = ctr
        context['asz'] = total
        return context

    def post(self, request, *args, **kwargs):
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        phonenumber = request.POST['phonenumber']
        email = request.POST['email']
        address = request.POST['address']

        chk = Checkout_details()
        chk.firstname = firstname
        chk.lastname = lastname
        chk.phonenumber = phonenumber
        chk.email = email
        chk.address = address
        chk.save()
        return render(request, 'customer/payment.html', {'message': ""})

class payment(TemplateView):
    def dispatch(self,request,*args,**kwargs):

        pid = self.request.user.id

        ch = Cart.objects.filter(user_id=pid,status='cart')


        print(ch)
        for i in ch:
            i.payment='paid'
            i.status='paid'
            i.delivery = 'delivered'
            i.billstatus = "null"
            i.save()
        return render(request,'customer/payment.html',{'message':" payment Success"})

class Buynow(TemplateView):
    template_name = 'customer/singleproduct_view.html'

    def dispatch(self, request, *args, **kwargs):
        pid = request.GET['id']
        product = Product.objects.get(pk=pid)
        try:

            if Cart.objects.filter(product_id=product.id, user_id=self.request.user.id, status='buy'):
                return render(request, 'customer/checkout1.html', {'message': "already added"})

            else:

                ca = Cart()
                farmer = Product.objects.get(pk=pid)
                price = farmer.price
                quantity=1
                Total = quantity * int(price)
                farmer.stock = int(farmer.stock) - int(quantity)
                a = int(farmer.stock) - int(quantity)
                if a <= 0:
                    return redirect(request.META['HTTP_REFERER'])
                else:
                    farmer.save()
                    farmer_reg = Farmer_Reg.objects.get(id=farmer.user_id)

                    ca.user = User.objects.get(id=self.request.user.id)
                    ca.farmer_id = farmer_reg.id
                    ca.product = Product.objects.get(pk=pid)
                    ca.payment = 'null'
                    ca.status = 'buy'
                    ca.quantity=quantity
                    ca.total=Total
                    ca.delivery = 'null'
                    ca.save()
                    ctlr = Cart.objects.filter(status='buy')

                    return render(request, 'customer/checkout1.html', {'message': "", 'ctlr': ctlr})
        except:

            ca = Cart()
            farmer = Product.objects.get(pk=pid)
            price = farmer.price
            quantity = 1
            Total = quantity * int(price)
            farmer.stock = int(farmer.stock) - int(quantity)
            a = int(farmer.stock) - int(quantity)
            if a <= 0:
                return redirect(request.META['HTTP_REFERER'])
            else:
                farmer.save()
                farmer_reg = Farmer_Reg.objects.get(id=farmer.user_id)

                ca.user = User.objects.get(id=self.request.user.id)
                ca.farmer_id = farmer_reg.id
                ca.product = Product.objects.get(pk=pid)
                ca.payment = 'null'
                ca.status = 'buy'
                ca.quantity=quantity
                ca.total=Total
                ca.delivery = 'null'
                ca.save()
                ctlr = Cart.objects.filter(status='buy')

                return render(request, 'customer/checkout1.html', {'message': "", 'ctlr': ctlr})

class Direct_payment(TemplateView):
    def dispatch(self,request,*args,**kwargs):

        pid = self.request.user.id

        ch = Cart.objects.filter(user_id=pid,status='buy')


        print(ch)
        for i in ch:
            i.payment='paid'
            i.status='paid'
            i.delivery = 'delivered'
            i.billstatus = "null"
            i.save()
        return render(request,'customer/payment1.html',{'message':" payment Successfull"})

class Direct_checkout(TemplateView):
    template_name = 'customer/checkout1.html'

    def post(self, request, *args, **kwargs):
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        phonenumber = request.POST['phonenumber']
        email = request.POST['email']
        address = request.POST['address']

        chk = Checkout_details()
        chk.firstname = firstname
        chk.lastname = lastname
        chk.phonenumber = phonenumber
        chk.email = email
        chk.address = address
        chk.save()
        return render(request, 'customer/payment1.html', {'message': ""})

class BookingView(TemplateView):
    template_name = 'customer/my_booking.html'
    def get_context_data(self, **kwargs):
        context = super(BookingView,self).get_context_data(**kwargs)
        usid=self.request.user.id
        b = Cart.objects.filter(status='paid',user_id=usid,delivery='delivered')

        context['booking'] = b
        return context

class Add_complaint(TemplateView):
    template_name = 'customer/add_complaint.html'

    def post(self, request, *args, **kwargs):
        user=User.objects.get(id=self.request.user.id)
        name= request.POST['name']
        email=request.POST['email']
        subject=request.POST['subject']
        complaint=request.POST['complaint']

        com = Compalaint()
        com.user=user
        com.name=name
        com.email=email
        com.subject=subject
        com.complaint=complaint
        com.status = 'added'
        com.save()
        return render(request, 'customer/add_complaint.html', {'message': "complaint added"})

class Complaint_replay(TemplateView):
    template_name = 'customer/view_complaintreplay.html'

    def get_context_data(self, **kwargs):
        context = super(Complaint_replay,self).get_context_data(**kwargs)

        replay = Compalaint.objects.filter(status='replied')

        context['replay'] = replay
        return context

class My_Profile(TemplateView):
    template_name = 'customer/my_profile.html'

    def get_context_data(self, **kwargs):
        context = super(My_Profile, self).get_context_data(**kwargs)
        usid = self.request.user.id

        view_cust = Customer_Reg.objects.get( user_id=usid)
        print(view_cust)

        context['view_cust'] = view_cust
        return context
    def post(self, request,*args,**kwargs):
        # fullname = request.POST['name']
        # last = request.POST['name1']


        if request.POST['profile'] == "pass":
         id = request.POST['id']
         password = request.POST['password']
         us = User.objects.get(pk=id)

         us.set_password(password)

         us.save()
        else:
         address = request.POST['address']
         id = request.POST['id']
         email = request.POST['email']
         name=request.POST['name']
         reg = Customer_Reg.objects.get(user=id)

         reg.address = address
         reg.save()
         us = User.objects.get(pk=id)
         us.username=email
         us.email = email
         us.first_name=name
         us.save()

        messages = "Update Successful."
        return render(request, 'customer/my_profile.html', {'message': "Update Successful"})
class feedback(TemplateView):
    template_name = 'customer/feedback.html'
    def get_context_data(self, **kwargs):
        context = super(feedback, self).get_context_data(**kwargs)
        userid = self.request.GET['id']
        feed= Product.objects.get(id=userid)

        context['feedback'] = feed
        return context

    def post(self, request, *args, **kwargs):
        user = User.objects.get(id=self.request.user.id)

        id2 = request.POST['product_id']
        farmer=Product.objects.get(id=id2)
        print(id2, 'hggvjkjkj')
        name = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']
        fe = Feedback()
        fe.farmer_id=farmer.user_id
        fe.user = user
        fe.product_id = id2

        fe.name = name
        fe.email = email
        fe.subject = subject
        fe.message = message
        fe.save()
        return render(request,'customer/productview.html',{'message':"Feedback Added"})
