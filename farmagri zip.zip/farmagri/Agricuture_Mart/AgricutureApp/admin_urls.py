from django.urls import path

from AgricutureApp.admin_views import IndexView, Farmer_Approvel, RejectView, ApproveView, Customer_approvel, \
    Complaint_View, Category, BookingView, Customer_View, farmer_View, Delete_Farmer

urlpatterns = [

    path('',IndexView.as_view()),
    path('farmer_approve',Farmer_Approvel.as_view()),
    path('cus_approve', Customer_approvel.as_view()),

    path('reject',RejectView.as_view()),
    path('approve',ApproveView.as_view()),
    path('view_compl',Complaint_View.as_view()),
    path('category',Category.as_view()),
    path('BookingView',BookingView.as_view()),
    path('Customer_View',Customer_View.as_view()),
    path('farmer_View',farmer_View.as_view()),
    path('delete',Delete_Farmer.as_view())

]
def urls():
    return urlpatterns, 'admin','admin'